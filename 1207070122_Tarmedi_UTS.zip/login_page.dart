import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';
import 'package:google_fonts/google_fonts.dart';

class Loginpage extends StatelessWidget {
  const Loginpage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Stack(children: [
      Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(
            image: DecorationImage(
                fit: BoxFit.cover, image: AssetImage("assets/picture.jpg"))),
      ),
      Column(children: [
        Container(
          margin: new EdgeInsets.only(
            top: 900,
            left: 20,
            right: 20,
          ),
          child: TextField(
            decoration: const InputDecoration(
              border: OutlineInputBorder(),
              labelText: 'Username',
            ),
            textCapitalization: TextCapitalization.sentences,
          ),
        ),
        Container(
          margin: new EdgeInsets.only(
            top: 50,
            bottom: 20,
            left: 20,
            right: 20,
          ),
          child: TextField(
            decoration: const InputDecoration(
              border: OutlineInputBorder(),
              labelText: 'Password',
            ),
            textCapitalization: TextCapitalization.sentences,
          ),
        ),
        SafeArea(
          child: Column(
            children: [
              Container(
                margin: EdgeInsets.symmetric(horizontal: 58,vertical: 14),
                child: Text("LOGIN",
                style: GoogleFonts.poppins(
                  fontweight: FontWeight.w600,
                  fontSize:24,
                )
                ),
              )
            ]
          ),
        )
      ])
    ]));
  }
}
